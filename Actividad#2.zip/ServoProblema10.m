%Sistema de ecuaciones 5

syms x y

A=[3 -2;
    0 1+y];
B=[7-y;
    5];

IA=inv(A);

%Soluci�n
Sol=IA*B;