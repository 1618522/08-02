%Sistema de ecuaciones 3

syms x

Sol=2*exp(x)+3*cos(x)

y=solve(Sol,x)