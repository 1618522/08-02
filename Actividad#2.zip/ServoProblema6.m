%Sistema de ecuaciones 1

syms x a

Sol=2*x+a-5

solve(Sol,x)
