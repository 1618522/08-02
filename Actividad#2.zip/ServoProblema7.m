%Sistema de ecuaciones 2

syms x a b

Sol=x.^2+a*x+b

y=solve(Sol,x)